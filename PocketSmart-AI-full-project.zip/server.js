import express from "express";
import dotenv from "dotenv";
import { GoogleGenerativeAI } from "@google/generative-ai";
import path from "path";
import { fileURLToPath } from "url";

dotenv.config();
const app = express();
const __dirname = path.dirname(fileURLToPath(import.meta.url));

app.use(express.json({ limit: "8mb" }));
app.use(express.static(path.join(__dirname, "public")));

const fallback = (type, data) => {
  const budget = Number(data.budget || 0);
  const base = type === "home"
    ? [
        ["Amazon", "LED Ceiling Light", Math.min(2499, Math.round(budget*.12)), "Modern, energy-efficient lighting"],
        ["IKEA", "Minimal Dining Table", Math.min(8999, Math.round(budget*.28)), "Clean Scandinavian-inspired design"],
        ["Amazon", "Ceiling Fan", Math.min(3299, Math.round(budget*.10)), "Energy-saving everyday comfort"],
        ["IKEA", "Storage Cabinet", Math.min(6999, Math.round(budget*.22)), "Space-saving storage"]
      ]
    : type === "party"
    ? [
        ["Swiggy", "Catering / Food Package", Math.round(budget*.45), "Flexible menu for your guest count"],
        ["Zomato", "Food & Dessert Options", Math.round(budget*.20), "Compare nearby restaurant options"],
        ["Local Vendors", "Decoration Package", Math.round(budget*.20), "Theme-based decoration"],
        ["OYO", "Guest Accommodation", Math.round(budget*.15), "Stay options when accommodation is needed"]
      ]
    : [
        ["Amazon", "Occasion Jewelry Set", Math.min(2499, Math.round(budget*.35)), "Versatile style for special occasions"],
        ["Flipkart", "Elegant Necklace Set", Math.min(1999, Math.round(budget*.30)), "Easy-to-match statement piece"],
        ["Amazon", "Earrings", Math.min(999, Math.round(budget*.15)), "Lightweight complementary pair"],
        ["Flipkart", "Bracelet", Math.min(799, Math.round(budget*.10)), "Simple finishing accessory"]
      ];
  return base.map((x,i)=>({id:i+1, platform:x[0], name:x[1], price:x[2], reason:x[3], url:"#"}));
};

app.post("/api/recommend", async (req,res) => {
  try {
    const { type, ...data } = req.body;
    if (!process.env.GEMINI_API_KEY) return res.json({source:"demo", recommendations:fallback(type,data)});

    const genAI = new GoogleGenerativeAI(process.env.GEMINI_API_KEY);
    // Use the current Gemini model available to your account if 1.5 Flash Pro is not enabled.
    const model = genAI.getGenerativeModel({ model: "gemini-1.5-flash" });

    const prompt = `You are PocketSmart AI, a budget planning assistant.
Return ONLY valid JSON with key "recommendations", an array of 6 objects.
Each object: platform, name, price (number in INR), reason, url.
Do not invent exact product URLs. Use "#" when no verified URL is available.
User planner: ${type}
User data: ${JSON.stringify(data)}
Prioritize affordability, usefulness, style preferences, and staying within the total budget.
For party planning, distribute suggestions across catering, decoration, entertainment/accommodation.
For home planning, cover the requested room/items.
For jewelry, consider occasion/style and outfit notes if provided.`;

    const result = await model.generateContent(prompt);
    const raw = result.response.text().replace(/```json|```/g,"").trim();
    const parsed = JSON.parse(raw);
    res.json({source:"gemini", recommendations:parsed.recommendations || []});
  } catch (err) {
    console.error(err);
    res.status(200).json({source:"demo-fallback", recommendations:fallback(req.body.type, req.body)});
  }
});

app.get("*", (_,res) => res.sendFile(path.join(__dirname,"public","index.html")));
app.listen(process.env.PORT || 3000, () => console.log(`PocketSmart AI running on http://localhost:${process.env.PORT || 3000}`));