# PocketSmart AI

A full-stack GenAI budget planning website for:
- Home Interior Planning
- Party Budget Planning
- Jewelry Recommendations

## Run locally

1. Install Node.js 18+.
2. Open this project folder in a terminal.
3. Run:
   ```bash
   npm install
   ```
4. Copy `.env.example` to `.env`.
5. Add your Gemini API key:
   ```env
   GEMINI_API_KEY=your_key
   ```
6. Start:
   ```bash
   npm start
   ```
7. Open `http://localhost:3000`

## Gemini note

The backend uses `gemini-1.5-flash` as the model identifier. If your Google AI account exposes a different/current model, change the `model` value in `server.js`.

The app works without an API key too: it automatically uses built-in demo recommendations, so the UI can be tested immediately.

## Production

For real marketplace recommendations, replace demo URLs with verified affiliate/product-search URLs or connect approved APIs/feeds. Do not present generated product URLs as verified links.
