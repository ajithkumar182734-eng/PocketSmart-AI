const form = document.getElementById("plannerForm");
const title = document.getElementById("formTitle");
const resultTitle = document.getElementById("resultTitle");
const generateBtn = document.getElementById("generateBtn");
const recommendations = document.getElementById("recommendations");
const badge = document.getElementById("sourceBadge");
const summary = document.getElementById("summary");
let type = "home";

const forms = {
 home: {
   title:"Home Interior Planner",
   html:`<div class="field"><label>Total budget (₹)</label><input name="budget" type="number" min="1000" placeholder="e.g. 100000" required></div>
   <div class="two"><div class="field"><label>Room</label><select name="room"><option>Living Room</option><option>Bedroom</option><option>Kitchen</option><option>Full Home</option></select></div>
   <div class="field"><label>Style</label><select name="style"><option>Modern</option><option>Minimal</option><option>Luxury</option><option>Traditional</option></select></div></div>
   <div class="field"><label>Items needed</label><div class="checks">
   <label><input type="checkbox" name="items" value="Lights" checked> Lights</label><label><input type="checkbox" name="items" value="Ceiling Fans"> Fans</label><label><input type="checkbox" name="items" value="Dining Table"> Dining table</label><label><input type="checkbox" name="items" value="Storage"> Storage</label></div></div>
   <div class="field"><label>Extra notes</label><textarea name="notes" rows="3" placeholder="Colors, size, must-haves..."></textarea></div>`
 },
 party:{
   title:"Party Budget Planner",
   html:`<div class="field"><label>Total budget (₹)</label><input name="budget" type="number" min="1000" placeholder="e.g. 50000" required></div>
   <div class="two"><div class="field"><label>Guests</label><input name="guests" type="number" min="1" placeholder="50" required></div>
   <div class="field"><label>Event type</label><select name="event"><option>Birthday</option><option>Wedding</option><option>Corporate</option><option>Anniversary</option><option>Get-together</option></select></div></div>
   <div class="two"><div class="field"><label>Venue</label><select name="venue"><option>Home</option><option>Hall</option><option>Restaurant</option><option>Outdoor</option></select></div>
   <div class="field"><label>City / area</label><input name="location" placeholder="e.g. Coimbatore"></div></div>
   <div class="field"><label>Priorities</label><div class="checks"><label><input type="checkbox" name="priority" value="Food" checked> Food</label><label><input type="checkbox" name="priority" value="Decoration" checked> Decor</label><label><input type="checkbox" name="priority" value="Entertainment"> Entertainment</label></div></div>`
 },
 jewelry:{
   title:"Jewelry Match Planner",
   html:`<div class="field"><label>Jewelry budget (₹)</label><input name="budget" type="number" min="500" placeholder="e.g. 5000" required></div>
   <div class="two"><div class="field"><label>Occasion</label><select name="occasion"><option>Wedding</option><option>Birthday</option><option>Party</option><option>Festival</option><option>Casual</option></select></div>
   <div class="field"><label>Style</label><select name="style"><option>Elegant</option><option>Minimal</option><option>Traditional</option><option>Statement</option><option>Trendy</option></select></div></div>
   <div class="field"><label>Preferred color</label><select name="color"><option>Gold</option><option>Silver</option><option>Rose Gold</option><option>Any</option></select></div>
   <div class="field"><label>Outfit image (optional)</label><div class="upload">Upload an outfit photo<input name="image" type="file" accept="image/*"></div></div>
   <div class="field"><label>Style notes</label><textarea name="notes" rows="2" placeholder="Neckline, outfit color, preferred look..."></textarea></div>`
 }
};

function renderForm(){
 title.textContent=forms[type].title;
 form.innerHTML=forms[type].html;
 resultTitle.textContent= type==="home"?"Your curated home picks":type==="party"?"Your party shortlist":"Your jewelry shortlist";
}
document.querySelectorAll(".planner-card").forEach(btn=>btn.addEventListener("click",()=>{
 document.querySelectorAll(".planner-card").forEach(x=>x.classList.remove("active"));
 btn.classList.add("active"); type=btn.dataset.type; renderForm();
}));
renderForm();

form.addEventListener("submit",e=>e.preventDefault());
generateBtn.addEventListener("click", async ()=>{
 if(!form.reportValidity()) return;
 const fd=new FormData(form), data={type};
 for(const [k,v] of fd.entries()){
   if(k==="items"||k==="priority"){data[k]=(data[k]||[]).concat(v)} else if(k!=="image") data[k]=v;
 }
 const file=form.querySelector('[name="image"]')?.files?.[0];
 if(file) data.outfitImageName=file.name;
 generateBtn.disabled=true; generateBtn.textContent="Building your plan…";
 badge.textContent="AI working"; summary.style.display="none";
 try{
   const res=await fetch("/api/recommend",{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify(data)});
   const out=await res.json();
   badge.textContent=out.source==="gemini"?"Gemini curated":"Smart demo mode";
   renderResults(out.recommendations||[],data);
 }catch(err){
   badge.textContent="Offline demo";
   renderResults([],data);
 }finally{
   generateBtn.disabled=false; generateBtn.innerHTML='Generate recommendations <span>✦</span>';
 }
});

function money(n){return "₹"+Number(n||0).toLocaleString("en-IN")}
function renderResults(items,data){
 const total=items.reduce((a,x)=>a+Number(x.price||0),0);
 summary.style.display="block";
 summary.innerHTML=`<b>Budget:</b> ${money(data.budget)} &nbsp; · &nbsp; <b>Suggested basket:</b> ${money(total)} &nbsp; · &nbsp; <b>Remaining:</b> ${money(Math.max(0,Number(data.budget)-total))}`;
 if(!items.length){recommendations.innerHTML='<div class="empty"><div>✦</div><h3>No recommendations yet</h3><p>Try adjusting your budget or preferences.</p></div>';return}
 recommendations.innerHTML=items.map(x=>`<article class="rec"><div class="rec-top"><span class="platform">${esc(x.platform||"Marketplace")}</span><span class="price">${money(x.price)}</span></div><h3>${esc(x.name||"Recommended item")}</h3><p>${esc(x.reason||"Selected for your budget and preferences.")}</p><a href="${x.url&&x.url!="#"?x.url:"#"}" target="_blank" rel="noopener">View option →</a></article>`).join("");
}
function esc(v){return String(v).replace(/[&<>"']/g,c=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"}[c]))}